import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Random rnd = new Random();
        Scanner scr = new Scanner(System.in);

        System.out.println("Введите нужное количество карт : ");
        int numberOfCards = scr.nextInt();

        String[] cardNumber = new String[9];
        cardNumber[0] = " six ";
        cardNumber[1] = " seven ";
        cardNumber[2] = " eight ";
        cardNumber[3] = " nine ";
        cardNumber[4] = " ten ";
        cardNumber[5] = " Jack ";
        cardNumber[6] = " Queen ";
        cardNumber[7] = " King ";
        cardNumber[8] = " Joker ";
        String newCardNumber = cardNumber[rnd.nextInt(cardNumber.length)];


        String[] cardSuit = new String[4];
        cardSuit[0] = " Hearts ";
        cardSuit[1] = " Diamonds ";
        cardSuit[2] = " Clubs ";
        cardSuit[3] = " Spades ";
        String newCardSuit = cardSuit[rnd.nextInt(cardSuit.length)];


        for (int i = 1; i < numberOfCards; i++) {
            String newCardNumberl = cardNumber[rnd.nextInt(cardNumber.length)];
            String newCardSuitl = cardSuit[rnd.nextInt(cardSuit.length)];
            if (numberOfCards > 36) {
                System.out.println("There are only 36 cards in the deck");
                break;
            }
            System.out.println("Card rank - " + Arrays.toString(new String[]{newCardNumberl}) + " Suit - " + Arrays.toString(new String[]{newCardSuitl}));
        }
    }
}