import com.sun.source.tree.WhileLoopTree;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);


        //вводим количество денег на счету
        System.out.println("Введите сумму денег на вашем счету :");
        double myMoney = scr.nextDouble();


        //вводим лимит на снятие денег за раз
        int limitAtOnce = 500;
        System.out.println("Лимит снятия денег за раз :" + limitAtOnce + " Euro");


        //вводим количество  снятия денег
        int limitAtDay = 3;
        System.out.println("Лимит количества снятий денег :" + limitAtDay + " раз ");

        int firstWithdrawal =1;

       while (true){
           System.out.println("Введите сумму снятия денег :");
           double moneyWithdraw = scr.nextDouble();

           if (moneyWithdraw > limitAtOnce) {
                System.out.println("Сумма снятия превышает лимит снятия денег за раз.");
                break;
            } else if ( firstWithdrawal > limitAtDay) {
                System.out.println("Лимит количества снятий за день превышен.");
            break;
            } else {
               myMoney -= moneyWithdraw;
               System.out.println("Денег на счету на данный момент : " + myMoney);
               firstWithdrawal +=1;


            }

       }

    }
}


