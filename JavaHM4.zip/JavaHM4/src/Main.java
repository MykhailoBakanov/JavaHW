import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        //вводим количество денег на счету
        System.out.println("Введите сумму денег на вашем счету :");
        double mymoney = scr.nextDouble();
        //вводим лимит на снятие денег за раз
        int limitatonce = 500;
        System.out.println("Лимит снятия денег за раз :" + limitatonce + " Euro");
        //вводим количество  снятия денег
        int limitatday = 5;
        System.out.println("Лимит количества снятий денег :" + limitatday + " раз ");
        //водим сумму денег которые хочем снять
        System.out.println("Введите сумму снятия денег :");
        double moneywithdraw = scr.nextDouble();
        //ввести количество раз сколько нужно снять сумму
        System.out.println("Введите количество снятий  :");
        int numberofwithdrawls = scr.nextInt();
        do {

            if (moneywithdraw > limitatonce) {
                System.out.println("Сумма снятия превышает лимит снятия денег за раз.");
            } else if (numberofwithdrawls > limitatday) {
                System.out.println("Лимит количества снятий за день превышен.");
            } else {
                double newmoney = mymoney-(moneywithdraw*numberofwithdrawls);
                System.out.println("Баланс вашего счета : " + newmoney + " Euro");
            }
        } while (mymoney<0);

    }
}


