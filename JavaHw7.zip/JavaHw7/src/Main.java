import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);

        int[] randomNumber = new int[5];
        System.out.println("Введите 1 число: ");
        randomNumber[0] = scr.nextInt();
        System.out.println("Введите 2  число: ");
        randomNumber[1] = scr.nextInt();
        System.out.println("Введите 3  число: ");
        randomNumber[2] = scr.nextInt();
        System.out.println("Введите 4  число: ");
        randomNumber[3] = scr.nextInt();
        System.out.println("Введите 5  число: ");
        randomNumber[4] = scr.nextInt();
        boolean isSorted = false;
        int buf;

        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < randomNumber.length - 1; i++)
                if (randomNumber[i] > randomNumber[i + 1]) {
                    isSorted = false;

                    buf = randomNumber[i];
                    randomNumber[i] = randomNumber[i + 1];
                    randomNumber[i + 1] = buf;
                }
        }
        System.out.println(Arrays.toString(randomNumber));
    }

}