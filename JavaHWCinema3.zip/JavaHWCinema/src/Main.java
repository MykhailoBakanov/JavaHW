import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Random random = new Random();
        int SpecialNumber = random.nextInt(1000, 10000);

        Seat num1 = new Seat("22", true);
        Seat num2 = new Seat("25", true);
        Seat num3 = new Seat("27", false);
        Seat num4 = new Seat("24", true);
        Seat num5 = new Seat("28", false);

        System.out.println("Все места : ");
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        System.out.println(num5);

        System.out.println("-------------------------------------------");

        System.out.println("Места на данный момент :");

        Ticket bilet1 = num1.booking();
        System.out.println(bilet1);
        Ticket bilet2 = num2.booking();
        System.out.println(bilet2);
        Ticket bilet3 = num3.booking();
        System.out.println(bilet3);
        Ticket bilet4 = num4.booking();
        System.out.println(bilet4);
        Ticket bilet5 = num5.booking();
        System.out.println(bilet5);


        System.out.println("-------------------------------------------");




    }
}

