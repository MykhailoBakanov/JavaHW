import java.util.Random;

public class Ticket {
    String numSeat;
    int specialNumber;

    public Ticket(String SeatNumber ) {
        Random random = new Random();
        this.specialNumber = random.nextInt(1000, 10000);
        this.numSeat = SeatNumber;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "numSeat='" + numSeat + '\'' +
                ", specialNumber=" + specialNumber +
                '}';
    }
}
