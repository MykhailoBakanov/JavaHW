public class Thermometer {
    double temperature;

    public Thermometer(double temperature) {
        this.temperature = temperature;
    }

    private long tempRound (double temp) {
        return Math.round(temp);
    }
    public double celsiusToFahrenheit(){
        return tempRound( temperature * 1.8 + 32);
    }
    public double fahrenheitToCelsius(){
        return tempRound((temperature-32)/1.8);
    }
}

// это было для уровня 1 :)

//public class Thermometer {
//    private long tempRound (double tempC) {
//        return Math.round(tempC);
//    }
//    public double celsiusToFahrenheit(double tempC){
//        return tempRound( tempC * 1.8 + 32);
//    }
//    public double fahrenheitToCelsius(double tempF){
//        return tempRound((tempF-32)/1.8);
//    }
//}
