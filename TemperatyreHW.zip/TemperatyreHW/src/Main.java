import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);// реализуем сканер для ввода данных
        System.out.println("Введите значение температуры в Цельсиях : ");
        double tempC =scr.nextDouble(); //Вводим значение тмп. с плаващей точкой в Цельсиях

        Thermometer thermometer = new Thermometer(tempC); //вызываем метод 1 в класс меин

        System.out.println(thermometer.celsiusToFahrenheit());

        System.out.println("Введите значение температуры в Фарангейтах : ");
        double tempF= scr.nextDouble(); //Вводим значение тмп. с плаващей точкой в Фарангейтах
        Thermometer thermometer1 = new Thermometer(tempF);
        System.out.println(thermometer1.fahrenheitToCelsius());

    }
}