import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.println("Enter day's number in the week (Number from 1 to 7): ");
        int dayNow = scr.nextInt();

        System.out.println("Enter time (Number from 0 to 23): ");
        int timeNow = scr.nextInt();

        System.out.println("Enter 1 if alarm is enabled, otherwise 0");
        int isAlarmEnabled = scr.nextInt();

        SmartHouse smartHouse = new SmartHouse(timeNow, dayNow, isAlarmEnabled == 1 );

        smartHouse.doStuff();
        scr.close();
    }
}