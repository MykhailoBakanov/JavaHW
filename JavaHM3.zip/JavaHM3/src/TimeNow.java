public class TimeNow {
    int timeNow;

    public TimeNow(int timeNow) {
        this.timeNow = timeNow;
    }
}
