public class DayNow {
    int dayNow;

    public DayNow(int dayNow) {
        this.dayNow = dayNow;
    }
}
