public class SmartHouse {

    TimeNow timeNow;
    DayNow dayNow;
    Alarm alarm;
    Kettle kettle;
    Curtains curtains;

    public SmartHouse(int timeNow, int dayNow, Boolean isAlarmEnabled) {
        this.timeNow = new TimeNow(timeNow);
        this.dayNow = new DayNow(dayNow);
        this.alarm = new Alarm(isAlarmEnabled);
        this.kettle = new Kettle();
        this.curtains = new Curtains();
    }

    public void doStuff() {

        if (dayNow.dayNow <= 5 && timeNow.timeNow == 8 && !alarm.isEnabled) {
            curtains.toRaise();
        }
        if (dayNow.dayNow > 5 && timeNow.timeNow == 11 && !alarm.isEnabled) {
            curtains.toRaise();
        }
        if (dayNow.dayNow <= 5 && timeNow.timeNow == 20 && alarm.isEnabled) {
            kettle.toBoil();
        }
        if (dayNow.dayNow <= 5 && timeNow.timeNow == 23 && curtains.isRaised) {
            curtains.toLower();
        }

    }
}
