public class Kettle {

    public void toBoil() {
        System.out.println("Kettle started heating");
    }

}
