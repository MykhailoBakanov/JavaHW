public class Alarm {
    Boolean isEnabled;

    public Alarm(Boolean alarm) {
        this.isEnabled = alarm;
    }
}