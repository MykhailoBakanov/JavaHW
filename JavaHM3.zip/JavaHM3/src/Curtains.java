public class Curtains {
    Boolean isRaised = true;

    public void toRaise() {
        this.isRaised = true;
        System.out.println("Curtains is raised");
    }

    public void toLower() {
        this.isRaised = false;
        System.out.println("Curtains is lowered");
    }

}
