import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); //добавить сканер

        System.out.println("Введите текст : " );//строка для ввода слов
        String str = sc.nextLine();
        System.out.println(str);

        System.out.println("Введите слово для его удаления из текста : " ); //строка для ввода отрицательного слова
        String newstr = str.replaceAll( sc.nextLine(),"" );

        System.out.println(newstr);//вывод остального текста
    }
}